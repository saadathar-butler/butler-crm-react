import { combineReducers } from 'redux'
import AuthStore from './AllStores/AuthStore'

export default combineReducers({
  AuthStore
})
