import { io } from 'socket.io-client'
import axios from 'axios';
import { useEffect, useState } from 'react';
import { DatePicker, Select, Table } from 'antd';

const { RangePicker } = DatePicker;

const socket = io(`${process.env.REACT_APP_BACKEND_URL}`)

function SalesReportDetails(props) {

    let [services, setServices] = useState([])
    let [date1, setDate1] = useState(new Date())
    let [date2, setDate2] = useState(new Date())
    let [cat, setCat] = useState("")
    let [status, setStatus] = useState("")

    let [jobs, setJobs] = useState([])
    let [filteredJobs, setFilteredJobs] = useState([])

    const columns = [
        {
            title: 'Serial no.',
            dataIndex: 's.no',
            key: 's.no',
            render: (i, record) => (
                `${new Date(record.dateCreated).getDate()}-${new Date(record.dateCreated).getMonth() + 1}-${new Date(record.dateCreated).getFullYear()} | ${new Date(record.dateCreated).getHours()}:${new Date(record.dateCreated).getMinutes()}:${new Date(record.dateCreated).getSeconds()}`
            ),
        },
        {
            title: 'Date',
            dataIndex: 'dateCreated',
            key: 'dateCreated',
            render: (i, record) => (
                i + 1
            ),
        },
        {
            title: 'Lead no.',
            dataIndex: 'leadNo',
            key: 'leadNo',
        },
        {
            title: 'Client name',
            dataIndex: 'customerName',
            key: 'customerName',
        },
        {
            title: 'Category',
            dataIndex: 'service',
            key: 'service',
        },
        {
            title: 'Description',
            dataIndex: 'description',
            key: 'description',
        },
        {
            title: 'Amount',
            dataIndex: 'amount',
            key: 'amount',
        },
        {
            title: 'Discounts',
            dataIndex: 'discount',
            key: 'discount',
        },
        {
            title: 'Received Amount',
            dataIndex: 'address',
            key: '7',
            render: (i, record) => (
                record.forAccounts[0] ? record.forAccounts[0].paymentReceived : 0
            ),
        },
        {
            title: 'Material Cost',
            dataIndex: 'address',
            key: '8',
            render: (i, record) => (
                record.forAccounts[0] ? record.forAccounts[0].material : 0
            ),
        },
        {
            title: 'Outsource Paid',
            dataIndex: 'address',
            key: '8',
            render: (i, record) => (
                record.forAccounts[0] ? record.forAccounts[0].outsourcePaid : 0
            ),
        },
        {
            title: 'Fuel Transportation',
            dataIndex: 'address',
            key: '8',
            render: (i, record) => (
                record.forAccounts[0] ? record.forAccounts[0].fuelTransportation : 0
            ),
        },
        {
            title: 'Card Repair',
            dataIndex: 'address',
            key: '8',
            render: (i, record) => (
                record.forAccounts[0] ? record.forAccounts[0].cardRepair : 0
            ),
        },
        {
            title: 'Gas Refill',
            dataIndex: 'address',
            key: '8',
            render: (i, record) => (
                record.forAccounts[0] ? record.forAccounts[0].gasRefill : 0
            ),
        },
        {
            title: 'Workshop Charges',
            dataIndex: 'address',
            key: '8',
            render: (i, record) => (
                record.forAccounts[0] ? record.forAccounts[0].workshopCharges : 0
            ),
        },
        {
            title: 'Machinery Rent',
            dataIndex: 'address',
            key: '8',
            render: (i, record) => (
                record.forAccounts[0] ? record.forAccounts[0].machineryRent : 0
            ),
        },
        {
            title: 'Payment mode',
            dataIndex: 'address',
            key: '8',
            render: (i, record) => (
                record.forAccounts[0] ? record.forAccounts[0].paymentMode : 0
            ),
        },
        {
            title: 'Status',
            dataIndex: 'status',
            key: '8',
        }
    ];

    const getJobs = () => {
        var config = {
            method: 'get',
            url: `${process.env.REACT_APP_BACKEND_URL}/api/jobs`,
            // url: 'http://localhost:5000/api/jobs'
        };

        axios(config)
            .then((res) => {
                setJobs(res.data)
            })
    }

    const getServices = () => {
        var config = {
            method: 'get',
            url: `${process.env.REACT_APP_BACKEND_URL}/api/service`,
            // url: 'http://localhost:5000/api/service'
        };

        axios(config)
            .then((res) => {
                setServices(res.data)
            })
    }

    useEffect(() => {
        getServices()
        getJobs()
    }, [])

    useEffect(() => {
        let dateArr = generateDateArray(date1, date2)
        if (jobs.length) {
            let jb = [...jobs]
            let jbs = jb.filter((a) => {
                return (
                    dateArr.filter((b) => b === a.dateCreated.split("T")[0]).length
                )
            })
            if (status) {
                jbs = jbs.filter((a) => {
                    return a.status === status
                })
            }
            if (cat) {
                jbs = jbs.filter((a) => {
                    return a.serviceId === cat
                })
            }
            setFilteredJobs(jbs)
        }
    }, [date1, date2, cat, status])


    function generateDateArray(startDate, endDate) {
        var dateArray = [];
        var currentDate = new Date(startDate);

        while (currentDate <= new Date(endDate)) {
            dateArray.push(currentDate.toISOString().slice(0, 10));
            currentDate.setDate(currentDate.getDate() + 1);
        }

        return dateArray;
    }

    return (
        <div className='reportInner p-3'>
            <h2>{props.name.split("-").join(" ")}</h2>
            <div className='filterDiv card p-3'>
                <h6>Filters</h6>
                <div className='row'>
                    <div className='col-3 flex-direction-column'>
                        <label>Select Date</label>
                        <RangePicker onChange={(e) => {
                            setDate1(e[0].$d)
                            setDate2(e[1].$d)
                        }} />
                    </div>
                    <div className='col-3 d-flex flex-column'>
                        <label>Category</label>
                        <Select
                            size="middle"
                            style={{ width: "100%" }}
                            onChange={(e) => setCat(e)}
                        >
                            {services.map((a, i) => {
                                return (
                                    <option value={a._id}>{a.name}</option>
                                )
                            })}
                        </Select>
                    </div>
                    <div className='col-3 d-flex flex-column'>
                        <label>Job Status</label>
                        <Select
                            size="middle"
                            style={{ width: "100%" }}
                            onChange={(e) => setStatus(e)}
                        >
                            <option value="New">New</option>
                            <option value="Not Responded">Not Responded</option>
                            <option value="Only Info">Only Info</option>
                            <option value="Scheduled">Scheduled</option>
                            <option value="On Hold">On Hold</option>
                            <option value="Cancelled">Cancelled</option>
                            <option value="Rejected">Rejected</option>
                            <option value="Fake">Fake</option>
                        </Select>
                    </div>
                </div>
            </div>

            <Table
                columns={columns}
                dataSource={filteredJobs}
                scroll={{
                    x: 3000,
                }}
            />
        </div>
    );
}

export default SalesReportDetails;