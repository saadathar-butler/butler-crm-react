import SideDrawerHome from "../../../common/sideDrawers/sideDrawerHome";


export default function Dashboard(props) {
    // console.log(props)
    return (
        <div className='d-flex'>
          Dashboard
        </div>
    );
}